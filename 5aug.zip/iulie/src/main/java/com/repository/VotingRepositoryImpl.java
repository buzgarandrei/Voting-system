package com.repository;

import com.entities.VotingSession;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Date;
import java.util.List;

@Repository
public class VotingRepositoryImpl implements VotingRepository {

    @PersistenceContext
    EntityManager entityManager;

    @Transactional
    public List<VotingSession> getVotingSessionList () {

        Date date = new Date();

        Query query =entityManager.createQuery("select vs from VotingSession vs", VotingSession.class);
        //Query query = entityManager.createNativeQuery("SELECT * FROM voting_session");

        List resultList = query.getResultList();
        return resultList;
    }
}
