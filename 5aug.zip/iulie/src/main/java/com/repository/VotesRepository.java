package com.repository;

import com.entities.Vote;

import java.util.List;

public interface VotesRepository {

    public List<Vote> getVotesList();
}
