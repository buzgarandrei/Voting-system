package com.repository;

import com.entities.Vote;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
@Repository
public class VotesRepositoryImpl implements VotesRepository {

    @PersistenceContext
    EntityManager entityManager;

    public List<Vote> getVotesList() {
        Query query = entityManager.createQuery("select v from Vote v", Vote.class);
        List<Vote> resultList = query.getResultList();
        return resultList;


    }
}
