package com.repository;

import com.entities.VotingSession;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


public interface VotingRepository {

    public List<VotingSession> getVotingSessionList();


}
