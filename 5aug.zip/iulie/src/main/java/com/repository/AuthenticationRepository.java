package com.repository;

import com.security.RoleType;

public interface AuthenticationRepository {

    public boolean isValid(String username, String password);

    public RoleType getUserRole(String username);

}
