package com.repository;

import com.security.RoleType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class AuthenticationRepositoryImpl implements AuthenticationRepository {

    @PersistenceContext
    private EntityManager entityManager;


    @Transactional(readOnly = true)
    @Override
    public boolean isValid(String username, String password) {

        Query query = entityManager.createNativeQuery("SELECT id FROM user " +
                "WHERE name = :username_abc COLLATE utf8mb4_0900_as_cs " +
                "AND password = :pass  COLLATE utf8mb4_0900_as_cs");

        query.setParameter("username_abc", username);
        query.setParameter("pass", password);

        List resultList = query.getResultList();
        if (resultList != null && !resultList.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }

    @Transactional(readOnly = true)
    @Override
    public RoleType getUserRole(String username) {

        Query query = entityManager.createNativeQuery("SELECT r.name " +
                "FROM user AS u " +
                "INNER JOIN role AS r ON u.id_role = r.id " +
                "WHERE u.name = :username ");

        query.setParameter("username", username);
        List resultList = query.getResultList();
        if(resultList == null || resultList.isEmpty() || resultList.size() > 1) {

            return null;
        }
        String roleStr =  (String) resultList.get(0);
        RoleType roleType = RoleType.valueOf(roleStr);
        return roleType;
    }
}
