package com.services;

import com.entities.Vote;
import com.repository.VotesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VoteServiceImpl implements VoteService {

    @Autowired
    public VotesRepository votesRepository;

    public List<Vote> getVotes() {
        return votesRepository.getVotesList() ;
    }
}
