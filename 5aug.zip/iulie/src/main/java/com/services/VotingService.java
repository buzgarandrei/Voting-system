package com.services;

import com.entities.VotingSession;
import com.repository.VotingRepository;

import java.util.List;

public interface VotingService {

    public List<VotingSession> getVotingSession();


}
