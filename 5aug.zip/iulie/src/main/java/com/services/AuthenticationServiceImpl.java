package com.services;

import com.repository.AuthenticationRepository;
import com.security.RoleType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    @Autowired
    private AuthenticationRepository authenticationRepository;

    public boolean isValid(String username, String password) {

        return authenticationRepository.isValid(username, password);
    }

    @Override
    public RoleType getUserRole(String username) {
        return authenticationRepository.getUserRole(username) ;
    }
}
