package com.services;

import com.security.RoleType;

public interface AuthenticationService {

    public boolean isValid(String username, String password);

    public RoleType getUserRole(String username);

}
