package com.services;

import com.entities.Vote;

import java.util.List;

public interface VoteService {

    public List<Vote> getVotes();
}
