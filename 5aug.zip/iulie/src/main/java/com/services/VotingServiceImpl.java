package com.services;

import com.entities.VotingSession;
import com.repository.VotingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VotingServiceImpl implements VotingService {

    @Autowired
    public VotingRepository votingRepository;

    public List<VotingSession> getVotingSession() {
        return votingRepository.getVotingSessionList();
    }
}
