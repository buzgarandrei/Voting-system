package com.services;

import com.entities.User;

import java.util.List;

public interface IUserService {

    List<User> findAll();

}
