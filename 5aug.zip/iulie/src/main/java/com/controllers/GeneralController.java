package com.controllers;

import com.dto.UserDto;
import com.dto.VoteDto;
import com.dto.VotingSessionDto;
import com.entities.User;
import com.entities.Vote;
import com.entities.VotingSession;
import com.security.RoleType;
import com.security.SecurityUtil;
import com.services.IUserService;
import com.services.VoteService;
import com.services.VotingService;
import com.services.VotingServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class GeneralController {

    @Autowired
    private IUserService userService;

    @Autowired
    private VotingService votingService;

    @Autowired
    private VoteService votesService;

    @RequestMapping("/")
    public String index(Model model) {
        return "index";
    }

    @RequestMapping("/user")
    public List<UserDto> showUsers(HttpSession httpSession, HttpServletRequest httpServletRequest) {

        boolean validated = SecurityUtil.validateTokenAndRole(httpSession, httpServletRequest, RoleType.ADMIN);
        if (!validated) {
            return null;
        }

        List<User> userList;
        userList = userService.findAll();

        List<UserDto> userDtos = userList.stream().map(this::convertToDto).collect(Collectors.toList());
        return userDtos;
    }

    private UserDto convertToDto(User user) {


        UserDto userDto = new UserDto(user.getId(),
                user.getCnp(),
                user.getPassword(),
                user.getName(),
                null,
                null,
                null);
        return userDto;

    }

    @RequestMapping("/votingSessions")
    public List<VotingSessionDto> getVotingSessions(HttpSession httpSession, HttpServletRequest httpServletRequest) {

        boolean validated = SecurityUtil.validateTokenAndRole(httpSession, httpServletRequest, null);
        if(!validated) {
            return null;
        }
        List<VotingSession> votingSessionList;
        votingSessionList = votingService.getVotingSession();


        List<VotingSessionDto> votingSessionDtos = votingSessionList.stream().map(this::ConvertToDto2).collect(Collectors.toList());
        return votingSessionDtos;
    }

    public VotingSessionDto ConvertToDto2(VotingSession votingSession) {

        VotingSessionDto votingSessionDto = new VotingSessionDto(
                votingSession.getNameOfVotingSession(),
                votingSession.getDate_start().toString(),
                votingSession.getDate_end().toString()
        );
        return votingSessionDto;
    }

    @RequestMapping("/vote")
    public List<Vote> getVotesList(HttpServletRequest httpServletRequest, HttpSession httpSession) {

        boolean validated = SecurityUtil.validateTokenAndRole(httpSession, httpServletRequest, null);
        if(!validated) {
            return null;
        }
        List<Vote> votesList;
        votesList = votesService.getVotes();
        return votesList;
       /* List<VoteDto> votesDtos = votesList.stream().map(this::ConvertToDto3).collect(Collectors.toList());
        return votesDtos;*/

    }
    public VoteDto ConvertToDto3(Vote vote) {

        VoteDto voteDto = new VoteDto(
                vote.getId(),
                vote.getVotingSession(),
                vote.getUserVoter(),
                vote.getUserCandidate(),
                vote.getDateOfVoting()
        );
        return voteDto;
    }
}
