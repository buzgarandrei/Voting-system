package com.controllers;

import com.dto.LoginDto;
import com.dto.request.LoginDtoReq;
import com.security.RoleType;
import com.security.UserSession;
import com.services.AuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.UUID;

@RestController
public class AuthenticationController {

    public static final String USER_SESSION = "USER_SESSION";

    @Autowired
    private AuthenticationService authenticationService;

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public LoginDto login(HttpSession httpSession, @RequestBody LoginDtoReq loginDtoReq) {

        String username = loginDtoReq.getUsername();
        String password = loginDtoReq.getPassword();

        boolean success = authenticationService.isValid(username, password);
        LoginDto loginDto = new LoginDto();
        loginDto.setSuccess(success);
        if (success) {

            String token = UUID.randomUUID().toString();
            loginDto.setToken(token);

            UserSession userSession = new UserSession();
            userSession.setToken(token);
            userSession.setUsername(username);

            RoleType roleType = authenticationService.getUserRole(username);
            userSession.setRoleType(roleType);

            httpSession.setAttribute(USER_SESSION, userSession);
        }
        return loginDto;
    }

    @RequestMapping(value = "/logout", method = RequestMethod.POST)
    @ResponseBody
    public void logout(HttpSession httpSession) {

        httpSession.removeAttribute(USER_SESSION);
    }

}
