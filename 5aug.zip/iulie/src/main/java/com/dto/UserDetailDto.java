package com.dto;

import com.entities.User;

import javax.persistence.*;


public class UserDetailDto {

    private Long id;
    private User user;
    private String county;
    private String locality;
    private String address;
    private String email;

    public UserDetailDto(){}

    public UserDetailDto(Long id, String county, String locality, String address, String email) {
        this.id = id;
        this.county = county;
        this.locality = locality;
        this.address = address;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
