package com.dto;

import com.entities.User;
import com.entities.VotingSession;

import java.util.Date;

public class VoteDto {

    private Long id;
    private VotingSession votingSession;
    private User userVoter;
    private User userCandidate;
    private Date dateOfVoting;

    public VoteDto() {
    }

    public VoteDto(Long id, VotingSession votingSession, User userVoter, User userCandidate, Date dateOfVoting) {
        this.id = id;
        this.votingSession = votingSession;
        this.userVoter = userVoter;
        this.userCandidate = userCandidate;
        this.dateOfVoting = dateOfVoting;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public VotingSession getVotingSession() {
        return votingSession;
    }

    public void setVotingSession(VotingSession votingSession) {
        this.votingSession = votingSession;
    }

    public User getUserVoter() {
        return userVoter;
    }

    public void setUserVoter(User userVoter) {
        this.userVoter = userVoter;
    }

    public User getUserCandidate() {
        return userCandidate;
    }

    public void setUserCandidate(User userCandidate) {
        this.userCandidate = userCandidate;
    }

    public Date getDateOfVoting() {
        return dateOfVoting;
    }

    public void setDateOfVoting(Date dateOfVoting) {
        this.dateOfVoting = dateOfVoting;
    }
}
