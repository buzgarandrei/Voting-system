package com.dto;

import java.util.ArrayList;
import java.util.List;

public class UserDto {

    private Long id;
    private String cnp;
    private String password;
    private String name;
    private RoleDto role;
    private UserDetailDto detail;
    private List<VotingSessionDto> votingSessions = new ArrayList<>();

    public UserDto() {
    }

    public UserDto(Long id, String cnp, String password, String name, RoleDto role, UserDetailDto detail, List<VotingSessionDto> votingSessions) {
        this.id = id;
        this.cnp = cnp;
        this.password = password;
        this.name = name;
        this.role = role;
        this.detail = detail;
        this.votingSessions = votingSessions;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCnp() {
        return cnp;
    }

    public void setCnp(String cnp) {
        this.cnp = cnp;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RoleDto getRole() {
        return role;
    }

    public void setRole(RoleDto role) {
        this.role = role;
    }

    public UserDetailDto getDetail() {
        return detail;
    }

    public void setDetail(UserDetailDto detail) {
        this.detail = detail;
    }

    public List<VotingSessionDto> getVotingSessions() {
        return votingSessions;
    }

    public void setVotingSessions(List<VotingSessionDto> votingSessions) {
        this.votingSessions = votingSessions;
    }
}
