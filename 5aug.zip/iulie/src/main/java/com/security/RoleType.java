package com.security;

public enum RoleType {

    ADMIN,
    CANDIDATE,
    VOTER;
}
