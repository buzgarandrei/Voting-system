package com.security;

import com.controllers.AuthenticationController;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.RequestFacade;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SecurityUtil {

    private static final String REQUEST_HEADER_TOKEN = "REQUEST_HEADER_TOKEN";


    public static boolean validateTokenAndRole(HttpSession httpSession, HttpServletRequest httpServletRequest, RoleType roleTypeRequested) {

        String requestHeaderToken = httpServletRequest.getHeader(REQUEST_HEADER_TOKEN);
        UserSession userSession = (UserSession) httpSession.getAttribute(AuthenticationController.USER_SESSION);

        if (requestHeaderToken == null || userSession == null || userSession.getToken() == null || !requestHeaderToken.equals(userSession.getToken())) {
            return false;
        }

        if(roleTypeRequested == null) {
            return true;
        }

        RoleType roleTypeLoggedUser = userSession.getRoleType();

        if(roleTypeLoggedUser == RoleType.ADMIN) {
            return true;
        }

        if (roleTypeLoggedUser != roleTypeRequested) {
            return false;
        }

        return true;
    }

}
