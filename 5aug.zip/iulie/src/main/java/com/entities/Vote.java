package com.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "vote")
public class Vote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @JoinColumn(name = "id_voting_session")
    @ManyToOne
    private VotingSession votingSession;

    @JoinColumn(name = "id_user_voter")
    @ManyToOne
    private User userVoter;

    @JoinColumn(name = "id_user_candidate")
    @ManyToOne
    private User userCandidate;

    @Column(name = "date_of_voting")
    private Date dateOfVoting;

    public Vote() {
    }

    public Vote(VotingSession votingSession, User userVoter, User userCandidate, Date dateOfVoting) {
        this.votingSession = votingSession;
        this.userVoter = userVoter;
        this.userCandidate = userCandidate;
        this.dateOfVoting = dateOfVoting;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public VotingSession getVotingSession() {
        return votingSession;
    }

    public void setVotingSession(VotingSession votingSession) {
        this.votingSession = votingSession;
    }

    public User getUserVoter() {
        return userVoter;
    }

    public void setUserVoter(User userVoter) {
        this.userVoter = userVoter;
    }

    public User getUserCandidate() {
        return userCandidate;
    }

    public void setUserCandidate(User userCandidate) {
        this.userCandidate = userCandidate;
    }

    public Date getDateOfVoting() {
        return dateOfVoting;
    }

    public void setDateOfVoting(Date dateOfVoting) {
        this.dateOfVoting = dateOfVoting;
    }
}
