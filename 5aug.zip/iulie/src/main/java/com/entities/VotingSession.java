package com.entities;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Entity
@Table(name = "voting_session")
public class VotingSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToMany(mappedBy = "votingSessions")
    private List<User> candidates = new ArrayList<>();

    @Column(name = "nameOfVotingSession")
    private String nameOfVotingSession;

    @Column(name = "date_start")
    private Date date_start;

    @Column(name = "date_end")
    private Date date_end;

    //@Column (name = "candidates")
    //private User candidates;


    public VotingSession() {
    }

    public VotingSession(String nameOfVotingSession, Date date_start, Date date_end) {
        this.nameOfVotingSession = nameOfVotingSession;
        this.date_start = date_start;
        this.date_end = date_end;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<User> getCandidates() {
        return candidates;
    }

    public void setCandidates(List<User> candidates) {
        this.candidates = candidates;
    }

    public String getNameOfVotingSession() {
        return nameOfVotingSession;
    }

    public void setNameOfVotingSession(String nameOfVotingSession) {
        this.nameOfVotingSession = nameOfVotingSession;
    }

    public Date getDate_start() {
        return date_start;
    }

    public void setDate_start(Date date_start) {
        this.date_start = date_start;
    }

    public Date getDate_end() {
        return date_end;
    }

    public void setDate_end(Date date_end) {
        this.date_end = date_end;
    }

}
